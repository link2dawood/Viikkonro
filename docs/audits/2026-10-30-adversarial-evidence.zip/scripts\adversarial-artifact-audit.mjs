import fs from 'node:fs';import path from 'node:path';
const root=fs.realpathSync('/tmp/viikkonro-adversarial-audit-20261030/dist');
const origin='https://viikkonro.fi';const output='/tmp/viikkonro-adversarial-results';fs.mkdirSync(output,{recursive:true});
const files=(dir)=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(item=>item.isDirectory()?files(path.join(dir,item.name)):item.name.endsWith('.html')?[path.join(dir,item.name)]:[]);
const pages=new Map();const failures=[];
for(const file of files(root)){
 const relative=path.relative(root,file).replaceAll(path.sep,'/');const route=relative==='index.html'?'/':'/'+relative.slice(0,-5);const html=fs.readFileSync(file,'utf8');
 let nodes=[];
 try{nodes=[...html.matchAll(/<script\b[^>]*type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/g)].flatMap(match=>{const v=JSON.parse(match[1]);return v['@graph']??[v];});}catch(error){failures.push({route,issue:'invalid-jsonld',message:error.message});}
 const robots=[...html.matchAll(/<meta\b[^>]*name="robots"[^>]*>/g)].map(m=>m[0].match(/content="([^"]*)"/)?.[1]??'');
 const canonicals=[...html.matchAll(/<link\b[^>]*rel="canonical"[^>]*>/g)].map(m=>m[0].match(/href="([^"]*)"/)?.[1]);
 pages.set(route,{html,nodes,robots,canonicals});
}
const sitemap=fs.readFileSync(path.join(root,'sitemap.xml'),'utf8');const sitemapUrls=[...sitemap.matchAll(/<loc>([^<]+)<\/loc>/g)].map(m=>new URL(m[1]).pathname);
for(const route of sitemapUrls){const p=pages.get(route);if(!p){failures.push({route,issue:'sitemap-missing-html'});continue;}
 if(p.robots.length!==1||p.robots.some(v=>/noindex|\bnone\b/i.test(v)))failures.push({route,issue:'sitemap-robots',robots:p.robots});
 if(p.canonicals.length!==1||p.canonicals[0]!==origin+route)failures.push({route,issue:'canonical',canonicals:p.canonicals});
 if(p.nodes.filter(n=>n['@id']===origin+route+'#webpage').length!==1)failures.push({route,issue:'page-schema'});
 for(const match of p.html.matchAll(/<(?:script|link|img)\b[^>]*(?:src|href)="(\/assets\/[^"?#]+)[^\"]*"/g)){if(!fs.existsSync(path.join(root,match[1])))failures.push({route,issue:'missing-client-asset',asset:match[1]});}
}
const dangling=[];const seen=new Set();
function references(value,route,key=''){
 if(!value||typeof value!=='object')return;
 if(value['@id']?.startsWith(origin)&&value['@id'].endsWith('#webpage')){
  const target=new URL(value['@id']).pathname;const p=pages.get(target);
  if(!p||!p.nodes.some(n=>n['@id']===value['@id'])){
   const id=route+'|'+value['@id'];if(!seen.has(id)){seen.add(id);dangling.push({route,target,id:value['@id'],relation:key,targetHtmlExists:!!p,targetRobots:p?.robots});}
  }
 }
 for(const[k,v]of Object.entries(value)){if(Array.isArray(v))v.forEach(item=>references(item,route,k));else if(v&&typeof v==='object')references(v,route,k);}
}
for(const[route,page]of pages){for(const node of page.nodes){for(const[key,value]of Object.entries(node)){if(key!=='@id')references(value,route,key);}}}
const orphanTargets=[...new Set(dangling.map(item=>item.target))];
const result={source:'f57b848',htmlPages:pages.size,sitemapPages:sitemapUrls.length,failures,danglingSchemaReferences:dangling.length,distinctDanglingTargets:orphanTargets.length,targetSamples:orphanTargets.slice(0,25),references:dangling};
fs.writeFileSync(path.join(output,'artifact-results.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify({...result,references:dangling.slice(0,12)},null,2));