import fs from 'node:fs';import {chromium} from '/tmp/viikkonro-audit-tools/node_modules/playwright/index.mjs';
const out='/tmp/viikkonro-adversarial-results';fs.mkdirSync(out,{recursive:true});
const launch=()=>chromium.launch({headless:true,executablePath:'/home/link2dawood/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome'});
const browser=await launch();const results=[];
async function setup(zone,width=1280){const context=await browser.newContext({timezoneId:zone,viewport:{width,height:900}});await context.route('**/*',route=>new URL(route.request().url()).origin==='http://127.0.0.1:4189'?route.continue():route.abort());const page=await context.newPage();page.setDefaultTimeout(6000);return{context,page};}
try{
 for(const zone of['Europe/Helsinki','Pacific/Kiritimati']){
  const{context,page}=await setup(zone);await page.clock.install({time:new Date('2026-12-31T08:00:00Z')});await page.goto('http://127.0.0.1:4189/mika-vuosi-nyt',{waitUntil:'domcontentloaded'});await page.waitForTimeout(1200);
  results.push({case:'helsinki-date-at-year-boundary',zone,instant:'2026-12-31T08:00:00Z',expectedHelsinkiYear:2026,result:await page.locator('.lead').innerText(),facts:await page.locator('.result').innerText()});await context.close();
 }
 const{context,page}=await setup('Europe/Helsinki',320);await page.goto('http://127.0.0.1:4189/viikko-53-2026',{waitUntil:'domcontentloaded'});await page.waitForTimeout(600);
 const mobile = await page.evaluate(() => {
   const protruding = [...document.querySelectorAll('main *')].filter(el => {
     const rect = el.getBoundingClientRect();
     return rect.width > 0 && rect.right > innerWidth + 2 && !el.closest('.table-wrap');
   }).slice(0, 12).map(el => ({tag:el.tagName,text:el.textContent.trim().slice(0,80),class:el.className,width:el.getBoundingClientRect().width,right:el.getBoundingClientRect().right}));
   return {width:innerWidth,scrollWidth:document.documentElement.scrollWidth,protruding};
 });
 results.push({case:'mobile-week-overflow',...mobile});
 await page.screenshot({path:out+'/mobile-week-overflow.png',fullPage:false});
 await page.goto('http://127.0.0.1:4189/paivamaaralaskuri',{waitUntil:'domcontentloaded'});await page.waitForTimeout(400);await page.locator('#dc-start').fill('2035-12-31');await page.locator('#dc-amount').fill('1');await page.waitForTimeout(150);
 results.push({case:'ordinary-date-calculation-broken-link',result:await page.locator('.lookup .result').innerText(),link:await page.locator('.lookup .result a').getAttribute('href')});await context.close();
 const normal=await setup('Europe/Helsinki');await normal.page.goto('http://127.0.0.1:4189/yrityskalenteri',{waitUntil:'domcontentloaded'});await normal.page.waitForTimeout(1500);results.push({case:'company-calendar-without-networkidle',h1:await normal.page.locator('main h1').allTextContents(),editorReady:await normal.page.locator('.cc-editor[data-ready="true"]').count()});await normal.context.close();
}finally{await browser.close();}
const freezeBrowser=await launch();try{
 const page=await freezeBrowser.newPage();await page.route('**/*',route=>new URL(route.request().url()).origin==='http://127.0.0.1:4189'?route.continue():route.abort());await page.goto('http://127.0.0.1:4189/paivamaaralaskuri',{waitUntil:'domcontentloaded'});await page.waitForTimeout(400);await page.locator('#dc-unit').selectOption('arkipaivaa');
 const start=Date.now();const fill=page.locator('#dc-amount').fill('100000000').catch(error=>error.message);
 await Promise.race([fill,new Promise(resolve=>setTimeout(resolve,2500))]);
 const heartbeat=await Promise.race([page.evaluate(()=>document.querySelector('main h1')?.textContent).then(value=>({responsive:true,value})).catch(error=>({error:error.message})),new Promise(resolve=>setTimeout(()=>resolve({responsive:false}),2500))]);
 results.push({case:'working-day-large-input-watchdog',amount:'100000000',elapsedMs:Date.now()-start,...heartbeat});
}finally{await freezeBrowser.close();}
fs.writeFileSync(out+'/edge-results.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));