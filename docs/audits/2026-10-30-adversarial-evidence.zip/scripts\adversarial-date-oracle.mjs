import fs from 'node:fs';import {spawnSync} from 'node:child_process';
import {isoWeek,isoYear,mondayOf,dayOfYear,dateFromDayKey,helsinkiDayKey} from '../src/components/dateUtils.js';
const py=`import datetime,json
out=[]
d=datetime.date(1900,1,1)
while d<=datetime.date(2100,12,31):
 y,w,wd=d.isocalendar()
 mo=datetime.date.fromisocalendar(y,w,1)
 out.append([d.year,d.month,d.day,y,w,mo.year,mo.month,mo.day])
 d+=datetime.timedelta(days=1)
print(json.dumps(out))`;
const result=spawnSync('python3',['-c',py],{encoding:'utf8',maxBuffer:30*1024*1024});if(result.status!==0)throw new Error(result.stderr);
const cases=JSON.parse(result.stdout);const zones=['UTC','Europe/Helsinki','America/New_York','Asia/Karachi','Pacific/Kiritimati'];const totals=[];const mismatches=[];
for(const zone of zones){process.env.TZ=zone;let checked=0;
 for(const[y,m,d,iy,iw,my,mm,md]of cases){const date=new Date(y,m-1,d);if(date.getFullYear()!==y||date.getMonth()!==m-1||date.getDate()!==d)continue;checked++;
  const week=isoWeek(date),year=isoYear(date),monday=mondayOf(iw,iy);
  if(week!==iw||year!==iy||monday.getFullYear()!==my||monday.getMonth()+1!==mm||monday.getDate()!==md){if(mismatches.length<20)mismatches.push({zone,date:[y,m,d],expected:[iy,iw,my,mm,md],actual:[year,week,monday.getFullYear(),monday.getMonth()+1,monday.getDate()]});}
 }
 totals.push({zone,checked});
}
const pinned=[];for(const zone of zones){process.env.TZ=zone;for(const key of['2026-01-01','2026-07-01','2026-10-30','2026-12-31']){const d=dateFromDayKey(key);const[y,m,day]=key.split('-').map(Number);const expected=Math.round((Date.UTC(y,m-1,day)-Date.UTC(y,0,1))/86400000)+1;pinned.push({zone,key,localDay:[d.getFullYear(),d.getMonth()+1,d.getDate()].join('-'),ordinal:dayOfYear(d),expectedOrdinal:expected,helsinkiDay:helsinkiDayKey(d)});}}
const out={casesPerZone:cases.length,totals,mismatches,pinnedDayFailures:pinned.filter(r=>r.ordinal!==r.expectedOrdinal||r.localDay!==r.key.split('-').map(Number).join('-'))};
fs.mkdirSync('/tmp/viikkonro-adversarial-results',{recursive:true});fs.writeFileSync('/tmp/viikkonro-adversarial-results/date-oracle.json',JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));