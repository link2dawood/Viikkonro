import fs from 'node:fs';import path from 'node:path';import {chromium} from '/tmp/viikkonro-audit-tools/node_modules/playwright/index.mjs';import {routeMeta} from '../src/data/seo.js';
const browser=await chromium.launch({headless:true,executablePath:'/home/link2dawood/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome'});const output='/tmp/viikkonro-adversarial-results';const results=[];
try{
 const sunRows=[];
 for(const zone of['UTC','Europe/Helsinki','Asia/Karachi']){
  const context=await browser.newContext({timezoneId:zone});await context.route('**/*',route=>new URL(route.request().url()).origin==='https://viikkonro.fi'?route.continue():route.abort());const page=await context.newPage();
  await page.goto('https://viikkonro.fi/viikko-13-2026',{waitUntil:'networkidle',timeout:20000});await page.waitForTimeout(300);
  sunRows.push({zone,firstDay:await page.locator('.day').first().innerText()});await context.close();
 }
 fs.writeFileSync(output+'/sun-live-browser.json',JSON.stringify(sunRows,null,2));console.log(JSON.stringify({sunLive:sunRows},null,2));
 const root='/tmp/viikkonro-adversarial-audit-20261030/dist';
 const extra=['/viikko-53-2026','/kuukausi-2-2024','/vuosi-2027','/kalenteri-2027','/pyhat-2026/joulupaiva','/koululomat-2028','/kesaaika-2026','/tulostettava-kalenteri-2027','/nimipaivat/tanaan','/auringonlasku-helsinki'];
 const routes=[...new Set([...Object.keys(routeMeta),...extra])].filter(route=>{const file=path.join(root,route==='/'?'index.html':route+'.html');return fs.existsSync(file)&&!fs.readFileSync(file,'utf8').includes('http-equiv="refresh"');});
 const tasks=routes.flatMap(route=>[320,390,1280].map(width=>({route,width})));let index=0;
 await Promise.all(Array.from({length:4},async()=>{
  const context=await browser.newContext({timezoneId:'Europe/Helsinki'});await context.route('**/*',route=>new URL(route.request().url()).origin==='http://127.0.0.1:4189'?route.continue():route.abort());const page=await context.newPage();page.setDefaultTimeout(5000);
  while(index<tasks.length){const task=tasks[index++];try{await page.setViewportSize({width:task.width,height:900});const response=await page.goto('http://127.0.0.1:4189'+task.route,{waitUntil:'domcontentloaded',timeout:15000});await page.waitForTimeout(300);
   const state=await page.evaluate(()=>{
    const visible=el=>{const r=el.getBoundingClientRect();const style=getComputedStyle(el);return r.width>0&&r.height>0&&style.visibility!=='hidden'&&!el.closest('[hidden]');};
    const controls=[...document.querySelectorAll('main input,main select,main textarea')].filter(visible);const ids=[...document.querySelectorAll('[id]')].map(el=>el.id);
    return {h1:document.querySelectorAll('main h1').length,scrollWidth:document.documentElement.scrollWidth,width:innerWidth,overflow:document.documentElement.scrollWidth>innerWidth+1,duplicateIds:[...new Set(ids.filter((id,i)=>ids.indexOf(id)!==i))],unlabelled:controls.filter(el=>el.type!=='hidden'&&!el.labels?.length&&!el.getAttribute('aria-label')&&!el.getAttribute('aria-labelledby')).map(el=>({tag:el.tagName,type:el.type,id:el.id,placeholder:el.getAttribute('placeholder')}))};
   });results.push({...task,status:response.status(),...state});
  }catch(error){results.push({...task,error:error.message});}}
  await context.close();
 }));
 const failures=results.filter(row=>row.error||row.status!==200||row.h1!==1||row.overflow||row.duplicateIds?.length||row.unlabelled?.length);
 fs.writeFileSync(output+'/wide-ui.json',JSON.stringify({routes:routes.length,checks:results.length,failures,results},null,2));console.log(JSON.stringify({routes:routes.length,checks:results.length,failures},null,2));
}finally{await browser.close();}