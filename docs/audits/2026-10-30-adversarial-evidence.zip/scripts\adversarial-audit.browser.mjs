import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '/tmp/viikkonro-audit-tools/node_modules/playwright/index.mjs';
const base=process.env.AUDIT_BASE??'http://127.0.0.1:4189';
const output=process.env.AUDIT_OUTPUT??'/tmp/viikkonro-adversarial-results';
fs.mkdirSync(output,{recursive:true});
const browser=await chromium.launch({headless:true,executablePath:'/home/link2dawood/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome'});
const results=[];
const context=await browser.newContext({viewport:{width:1280,height:900},timezoneId:'Europe/Helsinki'});
await context.route('**/*',route=>new URL(route.request().url()).origin===new URL(base).origin?route.continue():route.abort());
const page=await context.newPage();page.setDefaultTimeout(7000);
const errors=[];page.on('pageerror',error=>errors.push(error.message));
const snap=async()=>page.evaluate(()=>({url:location.pathname,title:document.title,h1:document.querySelector('main h1')?.textContent,canonicals:[...document.querySelectorAll('link[rel="canonical"]')].map(el=>el.href),robots:[...document.querySelectorAll('meta[name="robots"]')].map(el=>el.content),schemaPages:[...document.querySelectorAll('script[type="application/ld+json"]')].flatMap(el=>{try{const data=JSON.parse(el.textContent);return(data['@graph']??[data]).filter(node=>node['@id']?.endsWith('#webpage')).map(node=>node['@id']);}catch{return[];}})}));
async function visit(route){await page.goto(base+route,{waitUntil:'networkidle',timeout:20000});await page.locator('main h1').waitFor();}
try{
 await visit('/kuukausi-10-2020');
 const archive=await snap();
 await page.locator('header.nav a[href="/"]').first().click();
 await page.waitForURL(base+'/');await page.getByRole('heading',{level:1,name:'Mikä viikko nyt on?',exact:true}).waitFor();await page.waitForTimeout(250);
 const afterNav=await snap();
 await visit('/');const freshHome=await snap();
 results.push({case:'archive-to-home-metadata',archive,afterNav,freshHome,unexpectedNoindex:afterNav.robots.some(v=>v.includes('noindex')),staleCanonical:afterNav.canonicals.some(v=>v!=='https://viikkonro.fi/')});
 await visit('/viikko-42-2026');const weekBefore=await snap();
 await page.locator('header.nav a[href="/laskurit"]').first().click();await page.waitForURL(base+'/laskurit');await page.getByRole('heading',{level:1,name:'Viikkolaskurit ja päivämäärätyökalut',exact:true}).waitFor();await page.waitForTimeout(250);
 results.push({case:'week-to-calculators-schema',before:weekBefore,after:await snap()});
 await visit('/viikko-paivamaaraksi');
 await page.locator('#wk').fill('1.5');await page.locator('#yr').fill('2026');await page.waitForTimeout(150);
 const decimal={case:'fractional-week',result:await page.locator('.lookup').innerText(),link:await page.locator('.lookup .open-link').getAttribute('href'),valid:await page.locator('#wk').evaluate(el=>el.validity.valid)};
 results.push(decimal);await page.screenshot({path:path.join(output,'fractional-week.png'),fullPage:false});
 await page.locator('#wk').fill('1');await page.locator('#yr').fill('2036');await page.waitForTimeout(150);
 const futureLink=await page.locator('.lookup .open-link').getAttribute('href');
 results.push({case:'out-of-horizon-week-result',result:await page.locator('.lookup').innerText(),link:futureLink,status:(await page.request.get(base+futureLink)).status()});
 await visit('/paivamaara-viikoksi');await page.locator('#dpick').fill('2036-06-01');await page.waitForTimeout(150);
 const dateLink=await page.locator('.lookup .open-link').getAttribute('href');
 results.push({case:'out-of-horizon-date-result',result:await page.locator('.lookup').innerText(),link:dateLink,status:(await page.request.get(base+dateLink)).status()});
 await page.locator('#dpick').fill('0099-01-04');await page.waitForTimeout(150);
 results.push({case:'year-below-100',input:await page.locator('#dpick').inputValue(),result:await page.locator('.lookup').innerText()});
 await visit('/paivamaaralaskuri');
 await page.locator('#dc-amount').fill('1e308');await page.waitForTimeout(300);
 results.push({case:'date-overflow',body:(await page.locator('body').innerText()).slice(0,1800),errors:[...errors]});
 await page.screenshot({path:path.join(output,'date-overflow.png'),fullPage:false});
 if(!process.env.AUDIT_SKIP_LAYOUT){
  const routes=['/','/viikko-53-2026','/kuukausi-2-2024','/kalenteri-2027','/paivamaara-viikoksi','/viikko-paivamaaraksi','/paivien-erotus','/paivamaaralaskuri','/tyopaivalaskuri','/tuntilaskuri','/ikalaskuri','/data/month','/data/working-days','/kalenteripohjat','/lomasuunnittelija','/yrityskalenteri','/ota-yhteytta'];
  for(const width of[320,390,1280]){
   await page.setViewportSize({width,height:900});
   for(const route of routes){
    try{await visit(route);const state=await page.evaluate(()=>({h1:document.querySelectorAll('main h1').length,overflow:document.documentElement.scrollWidth>innerWidth+1,duplicateIds:[...new Set([...document.querySelectorAll('[id]')].map(el=>el.id).filter((id,i,a)=>a.indexOf(id)!==i))],body:(document.querySelector('main')?.textContent??'').includes('Invalid Date')}));results.push({case:'layout',route,width,...state});}
    catch(error){results.push({case:'layout',route,width,error:error.message});}
   }
  }
 }
}catch(error){results.push({case:'harness-error',error:error.stack});}
finally{await browser.close();}
fs.writeFileSync(path.join(output,'browser-results.json'),JSON.stringify({base,results,errors},null,2));
console.log(JSON.stringify({base,output,results:results.filter(r=>r.case!=='layout'||r.overflow||r.h1!==1||r.duplicateIds?.length||r.error),layoutChecks:results.filter(r=>r.case==='layout').length,errors},null,2));