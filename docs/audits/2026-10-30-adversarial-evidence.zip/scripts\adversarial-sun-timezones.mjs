import fs from 'node:fs';import {createServer} from 'vite';
const vite=await createServer({root:'/tmp/viikkonro-adversarial-audit-20261030',configFile:false,optimizeDeps:{noDiscovery:true},server:{middlewareMode:true}});
try{
 const sun=await vite.ssrLoadModule('/src/data/sunTimes.js');const results=[];
 for(const zone of['UTC','Europe/Helsinki','America/New_York','Asia/Karachi','Pacific/Kiritimati']){
  process.env.TZ=zone;
  for(const week of[1,13,25,43,53])for(const row of sun.sunTimesForWeek(2026,week)){
   const expected=[row.date.getFullYear(),String(row.date.getMonth()+1).padStart(2,'0'),String(row.date.getDate()).padStart(2,'0')].join('-');
   const actual=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Helsinki',year:'numeric',month:'2-digit',day:'2-digit'}).format(row.sunrise);
   results.push({zone,week,expected,sunriseDay:actual,sunrise:sun.formatHelsinkiTime(row.sunrise),sunset:sun.formatHelsinkiTime(row.sunset),ok:actual===expected});
  }
 }
 const failures=results.filter(row=>!row.ok);const counts=Object.fromEntries(['UTC','Europe/Helsinki','America/New_York','Asia/Karachi','Pacific/Kiritimati'].map(zone=>[zone,failures.filter(row=>row.zone===zone).length]));
 const report={checks:results.length,failures:failures.length,byZone:counts,samples:failures.slice(0,12),results};fs.writeFileSync('/tmp/viikkonro-adversarial-results/sun-timezones.json',JSON.stringify(report,null,2));console.log(JSON.stringify({...report,results:undefined},null,2));
}finally{await vite.close();}