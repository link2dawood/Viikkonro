import fs from 'node:fs';
const origin='https://viikkonro.fi';
const cases=[
 ['/',[200]],['/?audit=1',[200]],['/viikko-42-2026',[200]],['/viikko-42-2026/',[301,308]],['/viikko-42-2026.html',[301,308]],['/week/42/2026',[301,308]],['/viikko-0-2026',[404]],['/viikko-54-2026',[404]],['/viikko-53-2025',[404]],['/viikko-1.5-2026',[404]],['/viikko-1-2036',[404]],['/kuukausi-13-2026',[404]],['/vuosi-999999999999999999999',[404]],['/viikko-42-2019',[301,308]],
 ['/data/month',[200]],['/data/month/',[301,308]],['/data/month.html',[301,308]],['/data/month/index.json',[200]],['/data/index.json',[200]],['/data/month/2026.xml',[200]],['/data/month/2036.csv',[404]],['/pohjat/yrityksen-vuosikalenteri/2027.xlsx',[200]],['/ics/viikkonumerot.ics',[200]],['/sitemap.xml',[200]],['/ai.txt',[200]],['/.well-known/ai.txt',[200]],['/tiimin-lomat/suunnittelu',[200]],['/api/v1/week?year=2026&week=42',[401]],['/api/newsletter',[405]],['/.env',[404]],['/.git/config',[404]],['/en',[301,308]],['/assets/adversarial-missing-f57b848.js',[404]],['/assets/adversarial-missing-f57b848.js',[404]]
];
const results=[];
for(let offset=0;offset<cases.length;offset+=4){
 const batch=await Promise.allSettled(cases.slice(offset,offset+4).map(async([path,expected])=>{
  const response=await fetch(origin+path,{redirect:'manual',signal:AbortSignal.timeout(25000)});const body=await response.text();
  const result={path,status:response.status,expected,statusOk:expected.includes(response.status),contentType:response.headers.get('content-type'),location:response.headers.get('location'),robots:response.headers.get('x-robots-tag'),cache:response.headers.get('cache-control'),edgeCache:response.headers.get('cf-cache-status'),csp:response.headers.get('content-security-policy'),bodyBytes:Buffer.byteLength(body)};
  if(path.includes('/api/'))result.responseSample=body.slice(0,150);
  if(path==='/tiimin-lomat/suunnittelu')result.privateRulesOk=result.robots==='noindex, nofollow, noarchive'&&result.cache?.includes('no-store')&&result.csp?.includes("frame-ancestors 'none'")&&!body.includes('googletagmanager.com')&&!body.includes('googlesyndication.com');
  return result;
 }));
 for(const result of batch)results.push(result.status==='fulfilled'?result.value:{statusOk:false,error:String(result.reason)});
}
fs.mkdirSync('/tmp/viikkonro-adversarial-results',{recursive:true});fs.writeFileSync('/tmp/viikkonro-adversarial-results/live-http.json',JSON.stringify(results,null,2));
console.log(JSON.stringify({checks:results.length,failures:results.filter(result=>!result.statusOk||result.privateRulesOk===false),results:results.filter(result=>result.path?.includes('/api/')||result.path?.includes('/assets/')||result.path?.includes('suunnittelu'))},null,2));