import csv,json,zipfile,datetime
from pathlib import Path
from xml.etree import ElementTree
root=Path('/tmp/viikkonro-adversarial-audit-20261030/dist')
counts={"csv":0,"xml":0,"xlsx":0,"pdf":0,"week_json":0}; failures=[]
for file in root.rglob('*.csv'):
 try:
  with file.open(encoding='utf-8-sig',newline='') as stream: rows=list(csv.reader(stream))
  if not rows: raise ValueError('empty CSV')
  width=len(rows[0])
  if any(len(row)!=width for row in rows): raise ValueError('inconsistent field count')
  counts['csv']+=1
 except Exception as error: failures.append({"path":str(file.relative_to(root)),"error":str(error)})
for file in root.rglob('*.xml'):
 try: ElementTree.parse(file);counts['xml']+=1
 except Exception as error: failures.append({"path":str(file.relative_to(root)),"error":str(error)})
for file in root.rglob('*.xlsx'):
 try:
  with zipfile.ZipFile(file) as archive:
   bad=archive.testzip()
   if bad: raise ValueError('CRC failure: '+bad)
   for name in archive.namelist():
    if name.endswith('.xml') or name.endswith('.rels'): ElementTree.fromstring(archive.read(name))
  counts['xlsx']+=1
 except Exception as error: failures.append({"path":str(file.relative_to(root)),"error":str(error)})
for file in root.rglob('*.pdf'):
 data=file.read_bytes()
 if not data.startswith(b'%PDF-') or b'%%EOF' not in data[-1024:]: failures.append({"path":str(file.relative_to(root)),"error":"invalid PDF boundaries"})
 else: counts['pdf']+=1
for file in root.glob('data/week/*/*.json'):
 if not file.stem.isdigit() or not file.parent.name.isdigit(): continue
 data=json.loads(file.read_text());year=int(file.parent.name);week=int(file.stem)
 monday=datetime.date.fromisocalendar(year,week,1);sunday=monday+datetime.timedelta(days=6)
 if data.get('startDate')!=monday.isoformat() or data.get('endDate')!=sunday.isoformat(): failures.append({"path":str(file.relative_to(root)),"error":"week dates disagree with Python ISO calendar","keys":list(data)})
 counts['week_json']+=1
report={"counts":counts,"failures":failures}
Path('/tmp/viikkonro-adversarial-results/download-integrity.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))